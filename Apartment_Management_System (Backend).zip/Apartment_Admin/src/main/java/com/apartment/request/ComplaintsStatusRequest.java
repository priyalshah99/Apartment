package com.apartment.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintsStatusRequest {

	private int status;
	
}
