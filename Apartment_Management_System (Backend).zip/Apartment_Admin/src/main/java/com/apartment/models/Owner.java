package com.apartment.models;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class Owner {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ownerId;
	private String name;
	private String contactNo;
	private String email;
	private LocalDate dateOfPurchase;
	private boolean active;
	private String password;
	
	
	/*
	 * @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy =
	 * "owner") private Positions positions;
	 * 
	 * @ManyToMany(mappedBy = "owner") Set<Election> election;
	 */
}
