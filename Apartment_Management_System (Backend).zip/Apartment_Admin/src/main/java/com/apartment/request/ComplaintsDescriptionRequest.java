package com.apartment.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintsDescriptionRequest {

		private String description;
}
